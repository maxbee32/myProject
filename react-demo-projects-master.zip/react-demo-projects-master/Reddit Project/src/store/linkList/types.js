export const GET_LINK_LIST = 'GET_LINK_LIST';
export const ADD_LINK = 'ADD_LINK';
export const UP_VOTE_LINK = 'UP_VOTE_LINK';
export const DOWN_VOTE_LINK = 'DOWN_VOTE_LINK';
export const DELETE_LINK = 'DELETE_LINK';
export const EDIT_LINK = 'EDIT_LINK';
