export const COPY_SUCCESS = "Password successfully copied to clipboard";
