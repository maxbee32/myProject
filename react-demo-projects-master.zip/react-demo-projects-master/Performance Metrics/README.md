# Measure Performance App

![](http://www.w3.org/TR/navigation-timing/timing-overview.png)
