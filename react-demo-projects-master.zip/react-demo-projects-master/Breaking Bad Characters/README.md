Hello, this project was inspired by [Traversy Media](https://www.youtube.com/channel/UC29ju8bIPH5as8OGnQzwJyA) which creates wonderful project on his youtube channel about web development and programming tutorials. You should definetely check that out if you want to learn more about.

[Link to project video](https://www.youtube.com/watch?v=YaioUnMw0mo&t=1799s)

**Project Installation**

- `yarn install` or `npm install`
- `yarn start` or `npm start`

**Tools and libraries**

- React, React hooks (useEffect, useState)
- Axios
- [Public Breaking Bad API](https://breakingbadapi.com/documentation)
