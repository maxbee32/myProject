import React from 'react';

export const SubmitButton = () => {
  return (
    <button className="a-submitBtn" type="submit">
      ADD
    </button>
  );
};
